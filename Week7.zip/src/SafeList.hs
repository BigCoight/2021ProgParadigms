-- | Implementation of "safe" list procedures.
module SafeList where

import Prelude hiding(head, tail, sum)

-- | 'head' returns the first element of a list if the list is not empty.
--
-- >>> head []
-- Nothing
--
-- >>> head [1]
-- Just 1
--
-- >>> head [1..10]
-- Just 1
head = undefined

-- | 'tail' returns a list without its first element if the list is not empty.
--
-- >>> tail []
-- Nothing
--
-- >>> tail [1]
-- Just []
--
-- >>> tail [1..10]
-- Just [2,3,4,5,6,7,8,9,10]
tail = undefined

-- | 'sum' sums the elements of a list if the list is not empty (a sum equals to
-- zero means that there __are__ elements in the list).
--
-- >>> sum []
-- Nothing
--
-- >>> sum [1]
-- Just 1
--
-- >>> sum [1..10]
-- Just 55
sum = undefined
